$(document).ready(function() {
    // Mobile navigation toggle
    $('.hamburger-menu').on('click', function() {
        $(this).toggleClass('open');
        $('.main-nav ul').toggleClass('open');
    });

    // Optional: Close mobile nav when a link is clicked
    $('.main-nav ul li a').on('click', function() {
        if ($('.hamburger-menu').hasClass('open')) {
            $('.hamburger-menu').removeClass('open');
            $('.main-nav ul').removeClass('open');
        }
    });

    // You can add more jQuery plugins or custom scripts here if needed for carousels, animations, etc.
});$(document).ready(function() {
    // Mobile navigation toggle
    $('.hamburger-menu').on('click', function() {
        $(this).toggleClass('open');
        $('.main-nav ul').toggleClass('open');
    });

    // Optional: Close mobile nav when a link is clicked
    $('.main-nav ul li a').on('click', function() {
        if ($('.hamburger-menu').hasClass('open')) {
            $('.hamburger-menu').removeClass('open');
            $('.main-nav ul').removeClass('open');
        }
    });

    // You can add more jQuery plugins or custom scripts here if needed for carousels, animations, etc.
});
$(document).ready(function() {
    // Hamburger menu functionality
    $('.hamburger-menu').click(function() {
        $('.main-nav ul').toggleClass('open');
        $(this).toggleClass('open');
    });

    // Smooth scrolling for anchor links
    $('a[href^="#"]').on('click', function(event) {
        var target = $(this.hash);
        if (target.length) {
            event.preventDefault(); // Prevent default jump
            $('html, body').animate({
                scrollTop: target.offset().top
            }, 800); // Scroll duration in milliseconds (e.g., 800ms)

            // Close mobile menu if open after clicking a link
            if ($('.main-nav ul').hasClass('open')) {
                $('.main-nav ul').removeClass('open');
                $('.hamburger-menu').removeClass('open');
            }
        }
    });
});